// Only the PUBLISHABLE key (sb_publishable_...) goes here.
// NEVER put the secret key (sb_secret_...) in this file.
const SUPABASE_URL = "https://tpllvwbgdcmziuzgwwzb.supabase.co";
const SUPABASE_KEY = "sb_publishable_dFo3Nn3uDpwG0B5gtaY1EA_QeUoQGnR";

const sb = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);